// Prominent in-product disclosure required by the Chrome Web Store user data
// policy: before any tab data leaves the extension, say exactly what is sent,
// where, and when, and get an explicit yes. Chrome's own permission prompt
// ("communicate with cooperating native applications") says none of that, so
// it does not count as consent on its own.
//
// Shared by the library UI (imported by ui/src/lib/consent.ts) and the chat
// side panel (loaded by chat/chat.html). One text, one stored answer.
(function (root) {
  const KEY = '8020_ai_consent';
  const VERSION = 1;
  const POINTS = [
    ['What is sent', 'The titles of the tabs an AI action works on (the web address when a tab has no title). For Sort and Assess, that is the saved tabs you choose. For Chat, it is the titles of your open tabs and your top saved tabs. Also sent: the text of any memories included, your collection names, the goals you write in 8020, and your chat messages. Page contents are never read or sent.'],
    ['Where it goes', 'To the 8020 companion program on your own computer, which passes it to the AI service you set it up with: Anthropic Claude, Jev through OpenRouter, or OpenAI Codex as a fallback when Claude is at its limit. That service’s own privacy terms apply.'],
    ['When', 'Only when you start an AI action, such as Sort, Assess, or Chat, or when you switch on optional auto-sort. Saving, searching, organizing, and restoring tabs never send anything.'],
    ['What it is not used for', 'Not advertising, not sale to anyone, not tracking you across sites. 8020 keeps no server copy.'],
  ];

  async function read() {
    if (typeof chrome === 'undefined' || !chrome.storage?.local) return null;
    const value = (await chrome.storage.local.get(KEY))[KEY];
    return value && value.version === VERSION ? value : null;
  }

  function el(tag, props, children) {
    const node = Object.assign(document.createElement(tag), props || {});
    for (const child of children || []) node.append(child);
    return node;
  }

  function showDialog() {
    return new Promise((resolve) => {
      const list = el('dl', {}, POINTS.flatMap(([term, text]) => [el('dt', { textContent: term }), el('dd', { textContent: text })]));
      const link = el('a', { href: 'https://8020.best/privacy', target: '_blank', rel: 'noreferrer', textContent: 'Read the full privacy policy' });
      const decline = el('button', { type: 'button', textContent: 'Not now' });
      const accept = el('button', { type: 'button', className: 'consent-accept', textContent: 'I agree, turn on AI features' });
      const dialog = el('dialog', { className: 'consent-dialog' }, [
        el('h2', { id: 'consent-title', textContent: 'Before AI features send anything' }),
        list,
        el('p', { className: 'consent-policy' }, [link, '. Saying no keeps every non-AI feature working.']),
        el('div', { className: 'consent-actions' }, [decline, accept]),
      ]);
      dialog.setAttribute('aria-labelledby', 'consent-title');
      const finish = (value) => { dialog.close(); dialog.remove(); resolve(value); };
      decline.addEventListener('click', () => finish(false));
      accept.addEventListener('click', () => finish(true));
      dialog.addEventListener('cancel', (event) => { event.preventDefault(); finish(false); });
      document.body.append(dialog);
      dialog.showModal();
      decline.focus();
    });
  }

  async function ensure() {
    if (await read()) return true;
    if (typeof document === 'undefined') return false;
    const accepted = await showDialog();
    if (accepted && chrome.storage?.local) await chrome.storage.local.set({ [KEY]: { version: VERSION, acceptedAt: new Date().toISOString() } });
    return accepted;
  }

  // The only way the UI should ask for companion access: disclosure first,
  // then Chrome's own permission prompt (the accept click is the gesture).
  async function requestAccess() {
    if (typeof chrome === 'undefined' || !chrome.permissions?.request) return false;
    if (!(await ensure())) return false;
    return chrome.permissions.request({ permissions: ['nativeMessaging'] });
  }

  async function revoke() {
    if (typeof chrome !== 'undefined' && chrome.storage?.local) await chrome.storage.local.remove(KEY);
  }

  const api = { KEY, VERSION, POINTS, has: async () => Boolean(await read()), ensure, requestAccess, revoke };
  if (typeof module !== 'undefined') module.exports = api;
  else root.AiConsent = api;
})(globalThis);
