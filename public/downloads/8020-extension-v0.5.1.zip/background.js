// Sort logic runs via Chrome Native Messaging (see ../server/native-host.js)
// -- Chrome launches that host itself, on demand, per message, so there's no
// server to keep running. It shells out to the `claude` CLI, using your
// Claude subscription, not a billed API key. One-time setup: see
// ../server/README.md.
importScripts('categories.js');
importScripts('rubric.js');
const { categoryName, categoryKey, consolidateCategories } = CategoryBuckets;
const NATIVE_HOST = "com.eightytwenty.sortserver";
const STORAGE_KEY = "8020_folders";
const MARKDOWN_KEY = "8020_markdown";
const MARKDOWN_UPDATED_AT_KEY = "8020_markdown_updated_at";
const FOCUS_ANALYSIS_KEY = "8020_focus_analysis";
const FOCUS_RECOMMENDATION_LIMIT = 5;
const BATCH_SIZE = 30;
// Concurrent `claude` processes. Deliberately small: each is a full
// runtime, and unbounded parallelism crashed them on Windows.
const MAX_CONCURRENT = 2;
// Reserved folder for tabs the model didn't match back. INVARIANT: it is
// never tiered. It is a holding pen, and the moment it carries a tier it
// leaves the Unsorted inbox and "Triage unsorted" can never see it again --
// which is exactly how 136 tabs ended up stranded in tier B.
const UNSORTED_FOLDER = "Unsorted";
// Most urgent first.
const TIER_ORDER = ["S", "A", "B", "C", "D", "F"];

// Human-readable mirror of the structured storage. The Markdown is stable
// within a day when only presentation state changes, so expanding a folder
// does not trigger a pointless native-host write.
function foldersToMarkdown(folders, date = new Date()) {
  const lines = ["# 8020 saved tabs", "", `Updated ${date.toISOString().slice(0, 10)}`, ""];
  for (const tier of [...TIER_ORDER, null]) {
    const tierFolders = folders.filter((folder) => folder.tier === tier);
    if (tierFolders.length === 0) continue;
    lines.push(`## ${tier || "Unsorted"}`, "");
    for (const folder of tierFolders) {
      lines.push(`### ${folder.name}`, "");
      for (const tab of folder.tabs) {
        lines.push(tab.kind === 'memory' ? `- Memory: ${tab.title}\n\n${tab.memory || ''}\n` : `- [${tab.title || tab.url}](${tab.url})`);
      }
      lines.push("");
    }
  }
  return lines.join("\n");
}

function generateId() {
  return Math.random().toString(36).substring(2, 11);
}

async function hasNativeMessagingPermission() {
  if (!chrome.permissions?.contains) return true;
  return chrome.permissions.contains({ permissions: ["nativeMessaging"] });
}

async function getFolders() {
  const data = await chrome.storage.local.get(STORAGE_KEY);
  const folders = data[STORAGE_KEY] || [];
  // Repair on read: anything sitting in the reserved holding pen belongs in
  // the inbox, whatever tier a previous run stamped on it.
  const repaired = folders.map((f) => (f.name === UNSORTED_FOLDER && f.tier !== null ? { ...f, tier: null } : f));
  return repaired;
}

let folderWriteQueue = Promise.resolve();

function setFolders(folders) {
  const input = typeof folders === 'function' ? folders : structuredClone(folders);
  const commit = async () => {
    const resolved = typeof input === 'function' ? await input(await getFolders()) : input;
    const snapshot = consolidateCategories(structuredClone(resolved));
    if (JSON.stringify(snapshot) !== JSON.stringify(resolved)) {
      const current = await chrome.storage.local.get(STORAGE_KEY);
      await chrome.storage.local.set({ ['8020_before_category_merge_' + Date.now()]: current[STORAGE_KEY] || [] });
    }
    for (const folder of snapshot) for (const tab of folder.tabs) {
      tab.assessment = PriorityJudgment.assessment(tab.assessment, PriorityJudgment.inputFor(tab));
    }
    const existing = await chrome.storage.local.get(MARKDOWN_KEY);
    const markdown = foldersToMarkdown(snapshot);
    const markdownChanged = existing[MARKDOWN_KEY] !== markdown;
    const values = { [STORAGE_KEY]: snapshot };

    if (markdownChanged) {
      values[MARKDOWN_KEY] = markdown;
      values[MARKDOWN_UPDATED_AT_KEY] = new Date().toISOString();
    }

    // Structured data and its Markdown mirror commit together before any
    // captured tab is allowed to close.
    await chrome.storage.local.set(values);

    if (markdownChanged && (await hasNativeMessagingPermission())) {
      // A real local file is useful outside the protected extension page.
      // The native companion is optional, so a missing host must never break
      // saving or restoration.
      try {
        await sendNativeMessage({ type: "mirror_markdown", markdown });
      } catch {
        // chrome.storage.local remains the authoritative local mirror.
      }
    }
  };

  const operation = folderWriteQueue.then(commit, commit);
  folderWriteQueue = operation.catch(() => {});
  return operation;
}

// Batch label for a sweep. Dated rather than "Unsorted" so two sweeps in one
// session remain separable in the inbox instead of silently merging.
function batchName(allWindows) {
  const when = new Date().toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
  return `${when}${allWindows ? " (all windows)" : ""}`;
}

async function savedTabRecord(tab) {
  let group;
  if (typeof tab.groupId === "number" && tab.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE) {
    try {
      const sourceGroup = await chrome.tabGroups.get(tab.groupId);
      group = {
        title: sourceGroup.title || "Tab group",
        color: sourceGroup.color,
      };
    } catch {
      group = undefined;
    }
  }
  return {
    id: generateId(),
    title: tab.title || tab.url,
    url: tab.url,
    createdAt: new Date().toISOString(),
    ...(group ? { group } : {}),
  };
}

async function savedTabRecords(tabs) {
  return Promise.all(tabs.map(savedTabRecord));
}

function isCapturable(tab) {
  if (tab.pinned) return false;
  if (!tab.url) return false;
  if (/^(chrome|chrome-extension|edge|about):/.test(tab.url)) return false;
  return true;
}

// "Open work" guard. Before a save closes tabs, look inside each page for
// things you would lose: typed-in form fields, changed checkboxes or
// dropdowns, a compose box with text, or a page that asks before leaving.
// Those tabs stay open and are not saved. Playing tabs (music, calls) stay
// open too.
//
// This is a direct page check, not a model call: a model only sees the
// title, and a title can't say whether a form is half filled. It needs the
// optional "all sites" access; without it only the audio check runs.
function pageHasOpenWork() {
  const reasons = [];
  const skipTypes = new Set(["hidden", "submit", "button", "reset", "image", "search", "file"]);
  for (const el of document.querySelectorAll("input, textarea")) {
    const type = (el.type || "text").toLowerCase();
    if (skipTypes.has(type) || el.disabled || el.readOnly) continue;
    if (el.closest("[role=search], header, nav")) continue;
    if (type === "checkbox" || type === "radio") {
      if (el.checked !== el.defaultChecked) { reasons.push("changed a choice"); break; }
    } else if (el.value && el.value !== el.defaultValue) {
      reasons.push(type === "password" ? "typed a password" : "typed into a form");
      break;
    }
  }
  for (const sel of document.querySelectorAll("select")) {
    if (sel.multiple) {
      if ([...sel.options].some((o) => o.selected !== o.defaultSelected)) { reasons.push("changed a dropdown"); break; }
      continue;
    }
    // A single select with no default marked starts on its first option.
    const opts = [...sel.options];
    const initial = Math.max(0, opts.findIndex((o) => o.defaultSelected));
    if (opts.length && sel.selectedIndex !== initial) { reasons.push("changed a dropdown"); break; }
  }
  for (const box of document.querySelectorAll('[contenteditable="true"][role="textbox"], [contenteditable="plaintext-only"]')) {
    if ((box.innerText || "").trim().length > 0) { reasons.push("has a draft in a text box"); break; }
  }
  // Only visible in the page's own world: a site that asks "leave site?".
  if (typeof window.onbeforeunload === "function") reasons.push("asks before leaving");
  return reasons;
}

async function hasSiteAccess() {
  try {
    return await chrome.permissions.contains({ origins: ["<all_urls>"] });
  } catch {
    return false;
  }
}

// Map of tabId to the reason it should stay open.
async function findTabsWithOpenWork(tabs) {
  const keep = new Map();
  for (const tab of tabs) if (tab.audible) keep.set(tab.id, "is playing audio");
  if (!chrome.scripting || !(await hasSiteAccess())) return keep;

  await Promise.all(tabs.map(async (tab) => {
    if (keep.has(tab.id) || tab.discarded || !/^https?:/.test(tab.url || "")) return;
    const probe = chrome.scripting
      .executeScript({ target: { tabId: tab.id, allFrames: true }, world: "MAIN", func: pageHasOpenWork })
      .then((frames) => frames.flatMap((f) => f.result || []))
      .catch(() => []);
    // A hung or slow page must never block the save.
    const reasons = await Promise.race([probe, new Promise((r) => setTimeout(() => r([]), 1500))]);
    if (reasons.length) keep.set(tab.id, reasons[0]);
  }));
  return keep;
}

// Splits candidates into tabs to save and close, and tabs to leave alone.
async function splitOpenWork(tabs) {
  const keep = await findTabsWithOpenWork(tabs);
  return {
    toSave: tabs.filter((t) => !keep.has(t.id)),
    kept: tabs.filter((t) => keep.has(t.id)).map((t) => ({ title: t.title || t.url, reason: keep.get(t.id) })),
  };
}

async function getSavedPageUrl() {
  return chrome.runtime.getURL("saved/index.html");
}

async function focusOrOpenSavedPage() {
  const savedUrl = await getSavedPageUrl();
  const [existing] = await chrome.tabs.query({ url: savedUrl });
  if (existing) {
    // The tab can vanish between query() and update() (closed by hand,
    // navigated away, etc.), so fall through to opening a fresh one instead
    // of throwing an unhandled "No tab with id" rejection.
    try {
      await chrome.tabs.update(existing.id, { active: true });
      await chrome.windows.update(existing.windowId, { focused: true });
      return existing;
    } catch {
      // fall through
    }
  }
  return chrome.tabs.create({ url: savedUrl });
}

// Shown instead of Chrome's raw "Specified native messaging host not found"
// when someone without the optional companion tries an AI feature.
const COMPANION_MISSING = "AI needs the optional 8020 companion app, which isn't set up on this computer. Your tabs are saved and safe. You can still grade them by hand, or see 8020.best/support to set up AI.";
function isCompanionMissing(message) {
  return /native messaging host not found|host not found|forbidden|not installed|sendNativeMessage is not a function/i.test(String(message));
}

// chrome.runtime.sendNativeMessage's callback form, promisified. Chrome
// spawns the host fresh for this one message and tears it down after the
// response -- no persistent connection to manage.
function sendNativeMessage(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendNativeMessage(NATIVE_HOST, message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}

// Broadcasts to whatever extension pages happen to be listening (the saved
// page, if open) -- purely best-effort. If nothing is listening,
// sendMessage rejects with "Could not establish connection"; that's
// expected (not every trigger has a page open yet) and safe to swallow.
function broadcastProgress(action, done, total, itemCount, detail) {
  chrome.runtime.sendMessage({ type: "TRIAGE_PROGRESS", action, done, total, itemCount, detail }).catch(() => {});
}

// Turns one batch's raw response into the small summary the UI shows: which
// priority docs the classifier weighted against, and how this batch actually
// landed. Real returned data only -- no invented status text.
function summarizeBatch(response) {
  const tasks = response?.tasks || [];
  const tiers = {};
  const buckets = new Set();
  for (const item of tasks) {
    const tier = TIER_ORDER.includes(item.tier) ? item.tier : "?";
    tiers[tier] = (tiers[tier] || 0) + 1;
    if (item.bucket) buckets.add(item.bucket);
  }
  return {
    sources: response?.sources || null,
    model: response?.model || null,
    tiers,
    buckets: [...buckets],
    tabsInBatch: tasks.length,
  };
}

// Chunks titles into batches and runs them concurrently -- each batch spawns
// its own independent native-host + claude process anyway, so there's no
// reason to serialize them with an artificial delay between calls (that was
// leftover pacing from the old metered-API version; a personal subscription
// CLI has no shared rate limit to protect). All batches share the same
// existing-bucket-names snapshot as context (they can't see each other's
// picks mid-flight since they run in parallel), which trades a small chance
// of a near-duplicate bucket name across batches for cutting wall-clock time
// roughly by the batch count -- worth it for "often a lot" of tabs.
//
// onProgress(done, totalBatches, itemCount) fires once up front (done=0) and
// once per batch as it resolves, in whatever order they finish (not
// necessarily batch order, since they run in parallel) -- real signal, not a
// fake animation. itemCount is titles.length, passed through unchanged on
// every call so a listener can show "N tabs" instead of just a raw batch
// count that reads like the total number of tabs when it isn't.
async function sortTitles(titles, existingBucketNames, onProgress) {
  const rubric = await getRubricProfile();
  const batches = [];
  for (let i = 0; i < titles.length; i += BATCH_SIZE) {
    batches.push(titles.slice(i, i + BATCH_SIZE));
  }

  let completed = 0;
  onProgress?.(0, batches.length, titles.length);

  // Run at most MAX_CONCURRENT batches at once. Each one launches its own
  // `claude` process with a full runtime behind it, and firing four or more
  // together has been observed to take a process down hard on Windows
  // (exit 0xC0000409, STATUS_STACK_BUFFER_OVERRUN, with no output at all).
  // A small pool keeps throughput while staying well clear of that.
  const batchResults = new Array(batches.length);
  let next = 0;

  async function runOne(index) {
    const batch = batches[index];
    // One retry: the crash above is intermittent, so a whole sweep should not
    // be lost to a single unlucky process death.
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        return await sendNativeMessage({ type: "sort", batch, existingBuckets: existingBucketNames, rubric });
      } catch (err) {
        if (attempt === 1) throw err;
      }
    }
  }

  async function worker() {
    while (next < batches.length) {
      const index = next++;
      const res = await runOne(index);
      batchResults[index] = res;
      completed++;
      onProgress?.(completed, batches.length, titles.length, summarizeBatch(res));
    }
  }

  await Promise.all(
    Array.from({ length: Math.min(MAX_CONCURRENT, batches.length) }, () => worker())
  );

  const results = [];
  for (const response of batchResults) {
    if (response?.error) {
      throw new Error(response.error);
    }
    for (const item of response?.tasks || []) {
      results.push(item);
    }
  }

  return results;
}

// The server echoes each tab's title back verbatim alongside its bucket.
// Titles can repeat across tabs, so consume a FIFO queue per title to map
// results back to the right tab instances.
function matchResultsToTabs(tabs, results) {
  const queueByTitle = new Map();
  for (const tab of tabs) {
    const title = PriorityJudgment.inputFor(tab);
    if (!queueByTitle.has(title)) queueByTitle.set(title, []);
    queueByTitle.get(title).push(tab);
  }

  const matched = [];
  const unmatched = [];
  for (const item of results) {
    const queue = queueByTitle.get(item.text);
    const tab = queue && queue.length ? queue.shift() : null;
    const tier = TIER_ORDER.includes(item.tier) ? item.tier : null;
    if (tab) {
      matched.push({ tab: item.assessment ? { ...tab, assessment: item.assessment } : tab, bucket: item.bucket, tier });
    } else {
      unmatched.push(item);
    }
  }

  // Any tab whose title never made it back into a result (dropped/mangled by
  // the model) still gets saved, just unbucketed.
  const leftoverTabs = [];
  for (const queue of queueByTitle.values()) {
    leftoverTabs.push(...queue);
  }

  return { matched, leftoverTabs };
}

// Folder names offered to the model as reusable buckets. Excludes the
// reserved holding pen: offering it invites the model to file tabs there,
// which is what tiered it in the first place.
function bucketNamesFor(folders) {
  const names = new Map();
  for (const f of folders.filter(f => !f.archived && f.tier !== null)) {
    if (f.name !== UNSORTED_FOLDER) names.set(categoryKey(f.name), categoryName(f.name));
  }
  return [...names.values()];
}

function mergeIntoFolders(existingFolders, matched, leftoverTabs) {
  existingFolders = consolidateCategories(existingFolders);
  const byName = new Map(existingFolders.filter(f => !f.archived).map((f) => [categoryKey(f.name), f]));
  const tabsByBucket = new Map();
  const tiersByBucket = new Map();

  for (const { tab, bucket: rawBucket, tier, assessment } of matched) {
    const bucket = categoryKey(rawBucket);
    if (!tabsByBucket.has(bucket)) {
      tabsByBucket.set(bucket, []);
      tiersByBucket.set(bucket, []);
    }
    tabsByBucket.get(bucket).push(assessment ? { ...tab, assessment } : tab);
    tiersByBucket.get(bucket).push(tier);
  }

  const savedFolder = categoryKey(UNSORTED_FOLDER);
  if (leftoverTabs.length) {
    if (!tabsByBucket.has(savedFolder)) {
      tabsByBucket.set(savedFolder, []);
      tiersByBucket.set(savedFolder, []);
    }
    tabsByBucket.get(savedFolder).push(...leftoverTabs);
  }

  const updated = [...existingFolders];
  const addFolder = (name, tier, tabRecords) => {
    const folder = { id: generateId(), name, tier, tabs: tabRecords, expanded: false };
    byName.set(categoryKey(name), folder);
    updated.push(folder);
  };
  for (const [bucketKey, tabs] of tabsByBucket) {
    const firstMatch = matched.find(item => categoryKey(item.bucket) === bucketKey);
    const bucket = firstMatch ? categoryName(firstMatch.bucket) : UNSORTED_FOLDER;
    // These are already saved-tab records. Preserve their ids and metadata
    // so triage cannot erase stars, tasks, or original Chrome group details.
    const records = tabs.map((tab) => ({ ...tab, id: tab.id || generateId() }));

    // The holding pen stays untiered even if the model classified tabs into
    // it, which it can do whenever the name leaks into the bucket list.
    if (bucket === UNSORTED_FOLDER) {
      const pen = byName.get(categoryKey(bucket));
      if (pen) { pen.tabs.push(...records); pen.tier = null; } else addFolder(bucket, null, records);
      continue;
    }

    // Each tab keeps its own grade. A topic folder owns one tier, so when a
    // tab's grade differs from its topic folder's tier it goes to a sibling
    // folder ("Networking · S") instead of silently inheriting the folder's
    // tier. Inheriting is how a whole tab history once collapsed into one B
    // pile, and how S-grade job applications sat in a folder tiered F.
    // The folder's own tier is never changed once set, so a tier you chose
    // by hand stays yours.
    const tiers = tiersByBucket.get(bucketKey);
    const byTier = new Map();
    records.forEach((record, index) => {
      const tier = tiers[index] ?? null;
      if (!byTier.has(tier)) byTier.set(tier, []);
      byTier.get(tier).push(record);
    });
    for (const tier of [...TIER_ORDER, null].filter(t => byTier.has(t))) {
      const group = byTier.get(tier);
      const base = byName.get(categoryKey(bucket));
      if (!base) { addFolder(bucket, tier, group); continue; }
      if (tier === null || base.tier === tier) { base.tabs.push(...group); continue; }
      if (base.tier === null) { base.tier = tier; base.tabs.push(...group); continue; }
      const siblingName = `${bucket} · ${tier}`;
      const sibling = byName.get(categoryKey(siblingName));
      if (sibling && (sibling.tier === tier || sibling.tier === null)) { sibling.tier = tier; sibling.tabs.push(...group); }
      else addFolder(siblingName, tier, group);
    }
  }

  return consolidateCategories(updated);
}

// Saving the same page twice used to store it twice (one sweep had 190
// duplicates across 1,066 tabs). Two URLs are the same page when they differ
// only in "www.", a trailing slash, tracking parameters, or a text-highlight
// fragment. Other fragments stay significant: Gmail and Notion put the
// thread or event in the fragment.
function savedUrlKey(url) {
  try {
    const u = new URL(url);
    const host = u.host.toLowerCase().replace(/^www\./, "");
    const path = u.pathname.replace(/\/+$/, "");
    const params = u.search.slice(1).split("&").filter(p => p && !/^(utm_|ref=|fbclid|ext-referrer|screen_view)/i.test(p));
    const hash = u.hash.slice(1);
    const fragment = !hash || hash.startsWith(":~:") || hash === "overview" ? "" : "#" + hash;
    return `${u.protocol}//${host}${path}${params.length ? "?" + params.join("&") : ""}${fragment}`;
  } catch {
    return String(url || "");
  }
}

// Splits tabs about to be saved into new records and ones already saved
// (or repeated within this sweep). Both kinds are safe to close.
function withoutSavedDuplicates(tabs, folders) {
  const seen = new Set(folders.flatMap(f => f.tabs).filter(t => t.url).map(t => savedUrlKey(t.url)));
  const fresh = [];
  let duplicates = 0;
  for (const tab of tabs) {
    const key = savedUrlKey(tab.url);
    if (seen.has(key)) { duplicates++; continue; }
    seen.add(key);
    fresh.push(tab);
  }
  return { fresh, duplicates };
}

// Captures either the current window's tabs or every open window's tabs
// (allWindows=true -- e.g. a research window and a work window both get
// swept in one pass instead of needing a separate save per window), sorts
// them via the native host, merges into storage, and ONLY on success closes
// the captured tabs. Never closes tabs on a failed sort. Returns
// { savedCount, error }.
async function captureAndSort(allWindows = false) {
  const savedUrl = await getSavedPageUrl();
  const allTabs = allWindows
    ? (await chrome.windows.getAll({ populate: true })).flatMap((w) => w.tabs)
    : await chrome.tabs.query({ currentWindow: true });
  const candidates = allTabs.filter((t) => isCapturable(t) && t.url !== savedUrl);
  const { toSave: tabs, kept } = await splitOpenWork(candidates);

  if (tabs.length === 0) {
    return { savedCount: 0, error: null, kept };
  }

  const existingFolders = await getFolders();
  const { fresh, duplicates } = withoutSavedDuplicates(tabs, existingFolders);

  // Saving does NOT call the model. Captured tabs land untiered in the
  // Unsorted inbox as one dated batch, and Triage is the deliberate step that
  // buckets and tiers them later. Three things fall out of that:
  //   - saving is instant, instead of the 8-40s a classify round trip costs
  //   - nothing is spent until you actually ask for prioritisation
  //   - a sweep can never fail because the AI path is down
  // Tabs already saved are not stored again, but still close: a saved copy
  // of each one exists.
  if (fresh.length) {
    const batch = {
      id: generateId(),
      name: batchName(allWindows),
      tier: null,
      tabs: await savedTabRecords(fresh),
      expanded: false,
    };
    await setFolders([...existingFolders, batch]);
  }

  // Tabs are stored before anything is closed, and a tab can still vanish on
  // its own between the two. chrome.tabs
  // .remove(ids[]) throws for the WHOLE call if even one id is stale, so
  // close them individually and ignore ones that are already gone rather
  // than let a single stale id abort closing the rest.
  const closeResults = await Promise.allSettled(tabs.map((t) => chrome.tabs.remove(t.id)));
  const closedCount = closeResults.filter((r) => r.status === "fulfilled").length;

  return { savedCount: closedCount, error: null, kept, duplicates };
}

async function captureSpecificTabs(candidateTabs, label) {
  const savedUrl = await getSavedPageUrl();
  const candidates = candidateTabs.filter((tab) => isCapturable(tab) && tab.url !== savedUrl);
  const { toSave: tabs, kept } = await splitOpenWork(candidates);
  if (tabs.length === 0) return { savedCount: 0, error: null, kept };

  const existingFolders = await getFolders();
  const { fresh, duplicates } = withoutSavedDuplicates(tabs, existingFolders);

  // Persist first. The close step is allowed only after the saved copy exists.
  if (fresh.length) {
    const batch = {
      id: generateId(),
      name: label,
      tier: null,
      tabs: await savedTabRecords(fresh),
      expanded: false,
    };
    await setFolders([...existingFolders, batch]);
  }
  const closeResults = await Promise.allSettled(tabs.map((tab) => chrome.tabs.remove(tab.id)));
  return {
    savedCount: closeResults.filter((result) => result.status === "fulfilled").length,
    error: null,
    kept,
    duplicates,
  };
}

function tabDomain(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

function focusCandidateRecords(folders) {
  return folders
    .filter((folder) => !folder.archived)
    .flatMap((folder) =>
      folder.tabs
        .filter((tab) => tab.task !== "done" && !tab.fedAt)
        .map((tab) => ({
          id: tab.id,
          title: tab.title || tab.url,
          domain: tabDomain(tab.url),
          folder: folder.name,
          tier: folder.tier,
          starred: Boolean(tab.starred),
          task: tab.task || null,
        }))
    );
}

function projectRoutingCandidateRecords(folders) {
  return folders
    .filter((folder) => !folder.archived)
    .flatMap((folder) =>
    folder.tabs
      .filter((tab) => tab.task !== "done" && !tab.fedAt)
      .map((tab) => ({
      id: tab.id,
      title: tab.title || tab.url,
      domain: tabDomain(tab.url),
      folder: folder.name,
      tier: folder.tier,
      archived: Boolean(folder.archived),
      starred: Boolean(tab.starred),
      task: tab.task || null,
      }))
    );
}

function normalizeProjectRouting(response, candidates) {
  const projects = [];
  const projectByName = new Map();
  for (const item of Array.isArray(response?.projects) ? response.projects : []) {
    const name = typeof item?.name === "string" ? item.name.trim().slice(0, 160) : "";
    const projectPath = typeof item?.path === "string" ? item.path.trim().slice(0, 1000) : "";
    const summary = typeof item?.summary === "string" ? item.summary.trim().slice(0, 800) : "";
    if (!name || !projectPath || projectByName.has(name)) continue;
    const project = { name, path: projectPath, summary };
    projectByName.set(name, project);
    projects.push(project);
  }

  const rawRouteById = new Map();
  for (const item of Array.isArray(response?.routes) ? response.routes : []) {
    if (typeof item?.id === "string" && !rawRouteById.has(item.id)) rawRouteById.set(item.id, item);
  }

  const groups = new Map();
  const unrouted = [];
  const incomplete = [];
  for (const candidate of candidates) {
    const raw = rawRouteById.get(candidate.id);
    const projectName = typeof raw?.project === "string" ? raw.project.trim() : "";
    const project = projectByName.get(projectName) || null;
    const confidence = raw?.confidence === "high" || raw?.confidence === "medium" ? raw.confidence : "low";
    const route = {
      id: candidate.id,
      theme: String(raw?.theme || "Unclassified curiosity").trim().slice(0, 120),
      reason: String(raw?.reason || "No complete grounded project match was returned.").trim().slice(0, 800),
      confidence: project ? confidence : "low",
      complete: raw?.complete === true,
    };

    if (!route.complete) {
      incomplete.push(route);
      continue;
    }
    if (!project || confidence === "low") {
      unrouted.push(route);
      continue;
    }

    const key = `${project.name}\u0000${project.path}`;
    if (!groups.has(key)) groups.set(key, { ...project, tabs: [] });
    groups.get(key).tabs.push(route);
  }

  const groupedProjects = [...groups.values()].sort(
    (a, b) => b.tabs.length - a.tabs.length || a.name.localeCompare(b.name)
  );
  const matchedTabCount = groupedProjects.reduce((sum, project) => sum + project.tabs.length, 0);
  return {
    catalogCount: projects.length,
    analyzedTabCount: candidates.length,
    matchedTabCount,
    unroutedTabCount: unrouted.length,
    incompleteTabCount: incomplete.length,
    projects: groupedProjects,
    unrouted,
    incomplete,
  };
}

function normalizeFocusAnalysis(response, candidates, routingCandidates) {
  const candidateIds = new Set(candidates.map((candidate) => candidate.id));
  const seen = new Set();
  const recommendations = [];

  for (const item of Array.isArray(response?.recommendations) ? response.recommendations : []) {
    const id = typeof item?.id === "string" ? item.id : "";
    const goal = typeof item?.goal === "string" ? item.goal.trim() : "";
    const reason = typeof item?.reason === "string" ? item.reason.trim() : "";
    const nextStep = typeof item?.nextStep === "string" ? item.nextStep.trim() : "";
    if (!candidateIds.has(id) || seen.has(id) || !goal || !reason || !nextStep) continue;
    seen.add(id);
    recommendations.push({
      id,
      goal: goal.slice(0, 120),
      reason: reason.slice(0, 800),
      nextStep: nextStep.slice(0, 240),
    });
    if (recommendations.length === FOCUS_RECOMMENDATION_LIMIT) break;
  }

  const sources = Array.isArray(response?.sources)
    ? response.sources.map((source) => ({
        name: String(source?.name || "Priority source").slice(0, 80),
        role: String(source?.role || "").slice(0, 120),
        loaded: Boolean(source?.loaded),
      }))
    : null;

  return {
    version: 3,
    analyzedAt: new Date().toISOString(),
    analyzedTabCount: candidates.length,
    recommendations,
    projectRouting: normalizeProjectRouting(response, routingCandidates),
    sources,
    model: typeof response?.model === "string" ? response.model : null,
  };
}

async function analyzeSavedTabs() {
  if (!(await hasNativeMessagingPermission())) {
    return {
      analyzedCount: 0,
      error: "Enable optional local companion access before analyzing your saved tabs.",
      analysis: null,
    };
  }

  const folders = await getFolders();
  const candidates = focusCandidateRecords(folders);
  const routingCandidates = projectRoutingCandidateRecords(folders);
  let response = { recommendations: [], projects: [], routes: [], sources: null, model: null };

  if (candidates.length > 0 || routingCandidates.length > 0) {
    response = await sendNativeMessage({
      type: "analyze_focus",
      tabs: candidates,
      routingTabs: routingCandidates,
      limit: FOCUS_RECOMMENDATION_LIMIT,
    });
    if (response?.error) throw new Error(response.error);
  }

  const analysis = normalizeFocusAnalysis(response, candidates, routingCandidates);
  await chrome.storage.local.set({ [FOCUS_ANALYSIS_KEY]: analysis });
  return { analyzedCount: routingCandidates.length, error: null, analysis };
}

async function restoreSavedTabs(tabs, activateFirst = false) {
  const opened = [];
  const failedIds = [];

  for (const tab of tabs) {
    try {
      if (tab.kind === 'memory' || !tab.url) { failedIds.push(tab.id); continue; }
      const created = await chrome.tabs.create({ url: tab.url, active: false });
      opened.push({ saved: tab, created });
    } catch {
      failedIds.push(tab.id);
    }
  }

  const grouped = new Map();
  for (const item of opened) {
    if (!item.saved.group || typeof item.created.id !== "number") continue;
    const key = `${item.saved.group.title}\u0000${item.saved.group.color}`;
    if (!grouped.has(key)) grouped.set(key, { source: item.saved.group, tabIds: [] });
    grouped.get(key).tabIds.push(item.created.id);
  }

  for (const { source, tabIds } of grouped.values()) {
    try {
      const groupId = await chrome.tabs.group({ tabIds });
      await chrome.tabGroups.update(groupId, { title: source.title, color: source.color });
    } catch {
      // The tabs are still open. Group recreation is useful metadata, not a
      // reason to report the restore itself as failed or keep duplicates.
    }
  }

  if (activateFirst && opened[0]?.created?.id) {
    try {
      await chrome.tabs.update(opened[0].created.id, { active: true });
    } catch {
      // The tab opened successfully and may have been closed immediately.
    }
  }

  return { openedIds: opened.map((item) => item.saved.id), failedIds };
}

// Re-runs classification against everything ALREADY saved (not new browser
// tabs) -- a deliberate, explicit re-evaluation the user opted into by
// clicking "Triage tabs", so unlike the auto-tier-on-save merge, this fully
// replaces bucket AND tier for every tab, including ones you'd manually
// tiered. Picks up any FOCUS.md changes since the last save (classify.js
// reads it fresh per call), so re-triaging is also how a shifted priority
// list gets reflected in already-saved tabs.
async function triageExisting() {
  if (!(await hasNativeMessagingPermission())) {
    return {
      savedCount: 0,
      error: "Enable optional local companion access from the AI triage button first. Your tabs were not changed.",
    };
  }

  const existingFolders = await getFolders();

  // Only UNSORTED folders (tier === null) go to the model. Re-classifying
  // tabs you already tiered costs tokens to mostly reproduce the answer you
  // already have, and it throws away tiers you set by hand. Anything already
  // tiered is left exactly as-is.
  const untieredFolders = existingFolders.filter((f) => f.tier === null);
  const tieredFolders = existingFolders.filter((f) => f.tier !== null);
  // Memory text only leaves the device through the explicitly disclosed rubric action.
  // The legacy save-then-triage flow remains title-only.
  const untieredTabs = untieredFolders.flatMap((f) => f.tabs).filter(t => t.kind !== 'memory');
  const memoryFolders = untieredFolders.map(f => ({ ...f, tabs: f.tabs.filter(t => t.kind === 'memory') })).filter(f => f.tabs.length);

  if (untieredTabs.length === 0) {
    // Nothing to do, and crucially: no native-host call, so this is free.
    return { savedCount: 0, error: null, skipped: existingFolders.flatMap((f) => f.tabs).length };
  }

  const titles = untieredTabs.map(PriorityJudgment.inputFor);

  let results;
  try {
    // Existing bucket names include the tiered ones, so the model reuses a
    // folder you already have rather than inventing a near-duplicate name.
    results = await sortTitles(titles, bucketNamesFor(existingFolders), (done, total, itemCount, detail) =>
      broadcastProgress("triage", done, total, itemCount, detail)
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    const hint = isCompanionMissing(message) ? COMPANION_MISSING : message;
    return { savedCount: 0, error: hint };
  }

  const { matched, leftoverTabs } = matchResultsToTabs(untieredTabs, results);
  // Merge INTO the already-tiered folders rather than replacing everything:
  // a re-triage must not disturb tiers that are already settled.
  const updatedFolders = mergeIntoFolders([...tieredFolders, ...memoryFolders], matched, leftoverTabs);
  await setFolders(updatedFolders);

  return {
    savedCount: untieredTabs.length,
    error: null,
    skipped: existingFolders.flatMap((f) => f.tabs).length - untieredTabs.length,
  };
}

// Reorders the current window's real tabs by priority IN PLACE -- no saving,
// no closing, nothing leaves the tab strip. Least urgent on the left, most
// urgent on the right (so the next tab you'd naturally reach for/click into
// is the one that matters most). An alternative to captureAndSort for when
// you'd rather just process your actual open tabs than have them swept into
// a separate list.
async function sortTabsInPlace() {
  if (!(await hasNativeMessagingPermission())) {
    return {
      count: 0,
      error: "Enable optional local companion access from the AI sort button first. Your tabs were not changed.",
    };
  }

  const allTabs = await chrome.tabs.query({ currentWindow: true });
  const tabs = allTabs.filter((t) => isCapturable(t));

  if (tabs.length < 2) {
    return { count: 0, error: null };
  }

  const titles = tabs.map((t) => t.title || t.url);

  let results;
  try {
    results = await sortTitles(titles, [], (done, total, itemCount, detail) => {
      // Badge feedback for the right-click-menu trigger (no page open to show
      // a progress bar); broadcast too, for the saved-page button trigger.
      chrome.action.setBadgeText({ text: total > 1 ? `${done}/${total}` : "..." });
      broadcastProgress("reorder", done, total, itemCount, detail);
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    const hint = isCompanionMissing(message) ? COMPANION_MISSING : message;
    return { count: 0, error: hint };
  }

  const queueByTitle = new Map();
  for (const tab of tabs) {
    const title = tab.title || tab.url;
    if (!queueByTitle.has(title)) queueByTitle.set(title, []);
    queueByTitle.get(title).push(tab);
  }
  const tierByTabId = new Map();
  const bucketByTabId = new Map();
  for (const item of results) {
    const queue = queueByTitle.get(item.text);
    const tab = queue && queue.length ? queue.shift() : null;
    if (tab) {
      tierByTabId.set(tab.id, TIER_ORDER.includes(item.tier) ? item.tier : null);
      bucketByTabId.set(tab.id, item.bucket || "");
    }
  }

  const rankOf = (tier) => {
    const idx = TIER_ORDER.indexOf(tier);
    return idx === -1 ? TIER_ORDER.length : idx; // unmatched/untiered ranks after F
  };

  // Least urgent first (leftmost) -> most urgent last (rightmost); within the
  // same tier, cluster same-topic tabs together (alphabetical by bucket) so
  // e.g. every "Research" tab sits adjacent instead of interleaved with
  // same-tier tabs on unrelated topics. Stable sort keeps same-tier-same-
  // bucket tabs in their original relative order.
  const sorted = [...tabs].sort((a, b) => {
    const tierDiff = rankOf(tierByTabId.get(b.id)) - rankOf(tierByTabId.get(a.id));
    if (tierDiff !== 0) return tierDiff;
    return (bucketByTabId.get(a.id) || "").localeCompare(bucketByTabId.get(b.id) || "");
  });

  // Moving each tab to the very end, in target order, naturally produces
  // that order without computing exact indices ourselves -- Chrome keeps
  // pinned tabs forced leftmost regardless, and any tab this function
  // skipped (isCapturable false) just stays wherever it already was.
  for (const tab of sorted) {
    try {
      await chrome.tabs.move(tab.id, { index: -1 });
    } catch {
      // Closed by hand mid-sort -- nothing to lose here since this never
      // closes or deletes anything, just skip it.
    }
  }

  return { count: tabs.length, error: null };
}

importScripts('judgment-store.js');
importScripts('janitor.js');
const janitor = TabJanitor.createJanitor({
  chrome,
  record: savedTabRecord,
  save: matched => setFolders(current => mergeIntoFolders(current, matched, [])),
  classify: async tabs => {
    const buckets = bucketNamesFor(await getFolders());
    const decisions = [];
    for (let start=0; start<tabs.length; start+=30) {
      const batch = tabs.slice(start,start+30).map(t=>t.title||t.url);
      const response = await sendNativeMessage({type:'sort',batch,existingBuckets:buckets,rubric:await getRubricProfile()});
      if(response?.error) throw new Error(response.error);
      if(response?.model !== '~typesafe/jev-latest') throw new Error('Tab janitor requires Jev.');
      const remaining = [...(response.tasks||[])];
      for(const text of batch) {
        const index = remaining.findIndex(t=>t.text===text);
        if(index<0) throw new Error('Jev omitted a tab.');
        decisions.push(remaining.splice(index,1)[0]);
      }
    }
    return decisions;
  },
});
janitor.install();

// Clicking the toolbar icon just opens the saved page. It deliberately does
// NOT sweep the window: closing every tab you have open is destructive and
// far too easy to trigger by accident from a single stray click. Saving is an
// explicit choice, made with the Save window / Save all windows buttons.
chrome.action.onClicked.addListener(async () => {
  await focusOrOpenSavedPage();
});

// The saved-tabs page's "Save current window" button re-runs the same flow by
// messaging the worker, so there's one implementation of capture/sort/merge
// instead of duplicating it in saved.js.

// Chat: the side panel sends the conversation, this adds live context (every
// open tab plus a summary of the saved library) and asks the native host.
// Query strings and fragments are dropped before anything leaves Chrome,
// since they often carry tokens or personal search terms.
function chatSafeUrl(url) {
  try {
    const u = new URL(url);
    return `${u.hostname.replace(/^www\./, "")}${u.pathname === "/" ? "" : u.pathname}`;
  } catch {
    return String(url || "").split(/[?#]/)[0];
  }
}

async function chatContext() {
  const tabs = await chrome.tabs.query({});
  const openTabs = tabs
    .filter((t) => t.url && !t.url.startsWith("chrome") && !t.url.startsWith("about:"))
    .map((t) => ({ title: t.title || "", url: chatSafeUrl(t.url) }));
  const folders = (await getFolders()).filter((f) => !f.archived);
  const counts = {};
  for (const f of folders) counts[f.tier ?? "Unsorted"] = (counts[f.tier ?? "Unsorted"] || 0) + f.tabs.length;
  const top = folders
    .filter((f) => f.tier === "S" || f.tier === "A")
    .flatMap((f) => f.tabs.map((t) => `- [${f.tier}] ${String(t.title || t.url).slice(0, 110)}`))
    .slice(0, 80);
  const savedSummary = [
    "Tab counts by tier: " + (Object.entries(counts).map(([k, v]) => `${k} ${v}`).join(", ") || "none"),
    top.length ? "S and A tier saved tabs:\n" + top.join("\n") : "",
  ].filter(Boolean).join("\n");
  return { openTabs, savedSummary };
}

async function chat(messages) {
  const context = await chatContext();
  let response;
  try {
    response = await sendNativeMessage({ type: "chat", messages, ...context });
  } catch (err) {
    throw new Error(isCompanionMissing(err?.message) ? COMPANION_MISSING : err?.message || String(err));
  }
  if (!response) throw new Error("No response from the 8020 companion.");
  if (response.error) throw new Error(response.error);
  return { reply: response.reply, openTabCount: context.openTabs.length };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type?.startsWith('RUBRIC_') || message?.type === 'MEMORY_SAVE') {
    handleJudgmentMessage(message).catch(error => ({ error: error.message })).then(sendResponse);
    return true;
  }
  if (message?.type === 'JANITOR_CONFIGURE') {
    (async()=>{
      if (message.settings?.enabled && !(await hasNativeMessagingPermission())) throw new Error('Enable local companion access first.');
      return {settings:await janitor.configure(message.settings)};
    })().catch(error=>({error:error.message})).then(sendResponse);
    return true;
  }
  if (message?.type === "COMPANION_HEALTH") {
    sendNativeMessage({ type: "health" })
      .then((r) => sendResponse({ ok: !!r?.ok }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (message?.type === "CHAT") {
    chat(message.messages || [])
      .catch((err) => ({ error: err instanceof Error ? err.message : String(err) }))
      .then(sendResponse);
    return true;
  }
  if (message?.type === "CHAT_CONTEXT_COUNT") {
    chrome.tabs.query({}).then((tabs) => sendResponse({ count: tabs.length }));
    return true;
  }
  if (message?.type === "CAPTURE_AND_SORT") {
    captureAndSort()
      .catch((err) => ({ savedCount: 0, error: err instanceof Error ? err.message : String(err) }))
      .then(sendResponse);
    return true; // keep the message channel open for the async response
  }
  if (message?.type === "CAPTURE_AND_SORT_ALL_WINDOWS") {
    captureAndSort(true)
      .catch((err) => ({ savedCount: 0, error: err instanceof Error ? err.message : String(err) }))
      .then(sendResponse);
    return true;
  }
  if (message?.type === "TRIAGE_EXISTING") {
    triageExisting()
      .catch((err) => ({ savedCount: 0, error: err instanceof Error ? err.message : String(err) }))
      .then(sendResponse);
    return true;
  }
  if (message?.type === "SORT_TABS_IN_PLACE") {
    sortTabsInPlace()
      .catch((err) => ({ count: 0, error: err instanceof Error ? err.message : String(err) }))
      .then(sendResponse);
    return true;
  }
  if (message?.type === "ANALYZE_SAVED_TABS") {
    analyzeSavedTabs()
      .catch((err) => ({
        analyzedCount: 0,
        error: err instanceof Error ? err.message : String(err),
        analysis: null,
      }))
      .then(sendResponse);
    return true;
  }
  if (message?.type === "RESTORE_TABS") {
    restoreSavedTabs(Array.isArray(message.tabs) ? message.tabs : [], Boolean(message.activateFirst))
      .catch(() => ({ openedIds: [], failedIds: (message.tabs || []).map((tab) => tab.id) }))
      .then(sendResponse);
    return true;
  }
  if (message?.type === "PERSIST_FOLDERS") {
    const folders = Array.isArray(message.folders) ? message.folders : null;
    if (!folders) {
      sendResponse({ ok: false, error: "folders must be an array" });
      return false;
    }
    setFolders(folders)
      .then(() => ({ ok: true, error: null }))
      .catch((err) => ({ ok: false, error: err instanceof Error ? err.message : String(err) }))
      .then(sendResponse);
    return true;
  }
  if (message?.type === "SYNC_MARKDOWN") {
    getFolders()
      .then(setFolders)
      .then(() => ({ ok: true, error: null }))
      .catch((err) => ({ ok: false, error: err instanceof Error ? err.message : String(err) }))
      .then(sendResponse);
    return true;
  }
});

// Build the toolbar and page context menus from scratch so changes are
// idempotent across development reloads and extension updates.
chrome.runtime.onInstalled.addListener(() => {
  // Backfill the Markdown mirrors when this version is installed or updated.
  getFolders().then(setFolders).catch(() => {});
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: "open-8020", title: "Open 8020", contexts: ["action"] });
    chrome.contextMenus.create({ id: "open-chat", title: "Chat with 8020 about my tabs", contexts: ["action"] });
    chrome.contextMenus.create({ id: "save-tab", title: "Save just this tab", contexts: ["action"] });
    chrome.contextMenus.create({ id: "save-left", title: "Save tabs to the left", contexts: ["action", "page"] });
    chrome.contextMenus.create({ id: "save-right", title: "Save tabs to the right", contexts: ["action", "page"] });
    chrome.contextMenus.create({ id: "save-window", title: "Save this window", contexts: ["action"] });
    chrome.contextMenus.create({
      id: "sort-in-place",
      title: "AI sort tabs by priority (most urgent -> right)",
      contexts: ["action"],
    });
    chrome.contextMenus.create({ id: "save-selected", title: "Save selected tabs to 8020", contexts: ["page"] });
  });
});

chrome.runtime.onStartup.addListener(() => {
  getFolders().then(setFolders).catch(() => {});
});

// No page to report a result to for a right-click action, so feedback lives
// on the toolbar icon's badge instead: a working indicator while the AI call
// is in flight, briefly a red "!" (with the real error in the tooltip) if it
// failed, otherwise it just clears -- the reordered tabs are their own
// confirmation.
chrome.contextMenus.onClicked.addListener(async (info, clickedTab) => {
  if (info.menuItemId === "open-chat") {
    // Must be called synchronously inside the click gesture.
    if (clickedTab?.windowId !== undefined) chrome.sidePanel.open({ windowId: clickedTab.windowId });
    return;
  }
  if (info.menuItemId === "open-8020") {
    focusOrOpenSavedPage();
    return;
  }
  if (info.menuItemId === "save-window") {
    await captureAndSort();
    await focusOrOpenSavedPage();
    return;
  }
  if (info.menuItemId === "sort-in-place") {
    chrome.action.setBadgeText({ text: "..." });
    chrome.action.setBadgeBackgroundColor({ color: "#666666" });
    const result = await sortTabsInPlace();
    if (result.error) {
      chrome.action.setBadgeText({ text: "!" });
      chrome.action.setBadgeBackgroundColor({ color: "#b3311c" });
      chrome.action.setTitle({ title: `Sort failed: ${result.error}` });
      setTimeout(() => {
        chrome.action.setBadgeText({ text: "" });
        chrome.action.setTitle({ title: "Open 8020 priority tabs" });
      }, 6000);
    } else {
      chrome.action.setBadgeText({ text: "" });
    }
    return;
  }

  if (["save-tab", "save-selected", "save-left", "save-right"].includes(info.menuItemId)) {
    const query = Number.isInteger(clickedTab?.windowId)
      ? { windowId: clickedTab.windowId }
      : { currentWindow: true };
    const tabs = (await chrome.tabs.query(query)).sort((a, b) => a.index - b.index);
    const active = clickedTab?.id != null
      ? tabs.find((tab) => tab.id === clickedTab.id) || clickedTab
      : tabs.find((tab) => tab.active);
    let targets = [];
    if (info.menuItemId === "save-tab") {
      if (active) targets = [active];
    } else if (info.menuItemId === "save-selected") {
      targets = tabs.filter((tab) => tab.highlighted);
      if (targets.length === 0 && active) targets = [active];
    } else if (active) {
      targets = tabs.filter((tab) =>
        info.menuItemId === "save-left" ? tab.index < active.index : tab.index > active.index
      );
    }
    await captureSpecificTabs(targets, batchName(false));
    await focusOrOpenSavedPage();
  }
});

chrome.commands.onCommand.addListener(async (command, tab) => {
  if (command === "open-chat") {
    if (tab?.windowId !== undefined) chrome.sidePanel.open({ windowId: tab.windowId });
    return;
  }
  if (command === "open-8020") {
    await focusOrOpenSavedPage();
  } else if (command === "save-window") {
    await captureAndSort();
    await focusOrOpenSavedPage();
  } else if (command === "sort-open-tabs") {
    await sortTabsInPlace();
  }
});

function escapeOmniboxText(value) {
  return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

chrome.omnibox.onInputChanged.addListener(async (text, suggest) => {
  const query = text.trim().toLowerCase();
  if (!query) return suggest([]);
  const folders = await getFolders();
  const matches = [];
  for (const folder of folders) {
    for (const tab of folder.tabs) {
      if (tab.kind === 'memory') continue; // Memory titles open inside the library, not as URL suggestions.
      const haystack = `${tab.title} ${tab.url} ${folder.name}`.toLowerCase();
      if (!haystack.includes(query)) continue;
      matches.push({
        content: tab.url,
        description: `${escapeOmniboxText(tab.title || tab.url)} <dim>${escapeOmniboxText(folder.name)}</dim>`,
      });
      if (matches.length === 6) return suggest(matches);
    }
  }
  suggest(matches);
});

chrome.omnibox.onInputEntered.addListener(async (text) => {
  if (/^https?:\/\//i.test(text)) {
    await chrome.tabs.create({ url: text });
  } else {
    await focusOrOpenSavedPage();
  }
});
