// One deterministic scoring implementation for the worker, UI and native host.
(function (root) {
  const VERSION = 1;
  const NAME = '8020 Leverage';
  const KEY = '8020_rubric';
  const dimensions = [
    { id: 'goal', name: 'Goal fit', weight: 45, why: 'Importance comes first: advancing an active goal matters more than surface urgency.', anchors: ['No current goal connection', 'Possible future interest', 'Indirect support for active work', 'Directly advances an active goal', 'Removes a named blocker to an active goal'] },
    { id: 'action', name: 'Actionability', weight: 25, why: 'A concrete next step turns saved information into useful work.', anchors: ['No usable next step', 'Passive reading or inspiration', 'Useful reference for a next step', 'A specific feasible next action', 'Ready to act on immediately'] },
    { id: 'urgency', name: 'Urgency', weight: 20, why: 'Real time pressure matters, but cannot outweigh importance on its own.', anchors: ['No time pressure', 'Useful eventually', 'Useful this month', 'Verified deadline within seven days', 'Verified deadline today or immediate cost of delay'] },
    { id: 'recovery', name: 'Recoverability', weight: 10, why: 'Hard-to-recreate context deserves some protection without making every archive urgent.', anchors: ['Duplicate or trivial to find again', 'Generic searchable reference', 'Some effort to rediscover', 'Specific context difficult to recreate', 'Unique insight or source unlikely to be recoverable'] },
  ];
  const finite = n => typeof n === 'number' && Number.isFinite(n);
  const clean = (v, n = 600) => typeof v === 'string' ? v.slice(0, n) : '';
  const categoryKey = value => clean(value, 200).trim().toLowerCase().replace(/\s*\[[SABCDF]\]\s*$/i, '').replace(/\s+/g, ' ');
  const defaults = () => ({ version: VERSION, revision: 0, weights: Object.fromEntries(dimensions.map(d => [d.id, d.weight])), goals: '', corrections: [] });
  function profile(value) {
    const p = defaults();
    p.revision = Number.isSafeInteger(value?.revision) && value.revision >= 0 ? value.revision : 0;
    p.goals = clean(value?.goals, 2000);
    for (const d of dimensions) if (finite(value?.weights?.[d.id]) && value.weights[d.id] >= 0 && value.weights[d.id] <= 100) p.weights[d.id] = value.weights[d.id];
    if (!Object.values(p.weights).some(n => n > 0)) p.weights = defaults().weights;
    const seen = new Set();
    for (const c of (Array.isArray(value?.corrections) ? value.corrections : [])) {
      if (!c || typeof c.id !== 'string' || seen.has(c.id) || !finite(c.score) || c.score < 0 || c.score > 100) continue;
      seen.add(c.id);
      p.corrections.push({ id: clean(c.id, 200), category: categoryKey(c.category), score: c.score, reason: clean(c.reason), learn: c.learn === true, values: Object.fromEntries(dimensions.map(d => [d.id, validValue(c.values?.[d.id])])), at: clean(c.at, 40) });
    }
    return p;
  }
  function validValue(value) { return Number.isInteger(value) && value >= 0 && value <= 4 ? value : null; }
  function inputFor(item) { return item.kind === 'memory' ? `${item.title}\nMemory: ${item.memory || ''}` : (item.title || item.url || ''); }
  // Detect changed input without retaining a second copy of a private memory.
  function fingerprint(text) {
    let hash = 2166136261;
    for (let i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619);
    return (hash >>> 0).toString(16);
  }
  function assessment(value, input) {
    const compatible = value?.version === VERSION && (!input || value.inputHash === fingerprint(input));
    return { version: VERSION, inputHash: fingerprint(input || ''), provider: compatible ? clean(value.provider, 100) : 'unassessed', at: compatible ? clean(value.at, 40) : '', dimensions: Object.fromEntries(dimensions.map(d => {
      const e = compatible ? value?.dimensions?.[d.id] : null;
      const v = validValue(e?.value);
      return [d.id, { value: v, source: v === null ? 'unknown' : e?.source === 'user' ? 'user' : 'model', reason: v === null ? 'Not assessed. No evidence has been supplied.' : clean(e.reason), probability: finite(e?.probability) && e.probability >= 0 && e.probability <= 1 ? e.probability : null }];
    })) };
  }
  function baseScore(values, weights) {
    const total = dimensions.reduce((n, d) => n + weights[d.id], 0);
    return dimensions.reduce((n, d) => n + (values[d.id] ?? 0) / 4 * weights[d.id] / total * 100, 0);
  }
  function tier(score) { return score >= 85 ? 'S' : score >= 70 ? 'A' : score >= 50 ? 'B' : score >= 30 ? 'C' : score >= 10 ? 'D' : 'F'; }
  function evaluate(item, category, rawProfile) {
    const p = profile(rawProfile), a = assessment(item.assessment, inputFor(item));
    const total = dimensions.reduce((n, d) => n + p.weights[d.id], 0);
    const rows = dimensions.map(d => ({ ...d, ...a.dimensions[d.id], weight: p.weights[d.id], percent: p.weights[d.id] / total * 100, contribution: (a.dimensions[d.id].value ?? 0) / 4 * p.weights[d.id] / total * 100 }));
    const complete = rows.every(d => d.weight === 0 || d.value !== null);
    const values = Object.fromEntries(rows.map(d => [d.id, d.value]));
    const base = baseScore(values, p.weights);
    const learned = p.corrections.filter(c => c.id !== item.id && c.learn && c.category && c.category === categoryKey(category) && dimensions.every(d => p.weights[d.id] === 0 || c.values[d.id] !== null)).slice(-200);
    const adjustment = complete && learned.length ? Math.max(-20, Math.min(20, learned.reduce((n, c) => n + c.score - baseScore(c.values, p.weights), 0) / learned.length)) : 0;
    const override = p.corrections.find(c => c.id === item.id) || null;
    const computed = Math.round(Math.max(0, Math.min(100, base + adjustment)) * 10) / 10;
    const score = override ? override.score : complete ? computed : null;
    return { name: NAME, version: VERSION, revision: p.revision, rows, base, adjustment, learnedCount: learned.length, override, score, tier: score === null ? null : tier(score), complete, computed, provider: a.provider, assessedAt: a.at };
  }
  function correct(rawProfile, item, category, score, reason, learn) {
    const p = profile(rawProfile);
    p.corrections = p.corrections.filter(c => c.id !== item.id);
    if (score !== null) {
      if (!finite(score) || score < 0 || score > 100 || !clean(reason).trim()) throw new Error('Enter a score from 0 to 100 and a reason.');
      const a = assessment(item.assessment, inputFor(item));
      p.corrections.push({ id: item.id, category: categoryKey(category), score, reason: clean(reason).trim(), learn: Boolean(learn), values: Object.fromEntries(dimensions.map(d => [d.id, a.dimensions[d.id].value])), at: new Date().toISOString() });
    }
    p.revision++;
    return p;
  }
  function manualAssessment(item, values, reasons) {
    const result = assessment(null, inputFor(item));
    result.provider = 'user'; result.at = new Date().toISOString();
    for (const d of dimensions) {
      const value = values[d.id];
      if (value !== null && validValue(value) === null) throw new Error('Dimension ratings must be whole numbers from 0 to 4, or unknown.');
      if (value !== null && !clean(reasons[d.id]).trim()) throw new Error(`Add evidence for ${d.name}.`);
      result.dimensions[d.id] = { value, source: value === null ? 'unknown' : 'user', reason: clean(reasons[d.id]).trim(), probability: null };
    }
    return result;
  }
  const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  function card(item, category, rawProfile, includePrivate = false) {
    const r = evaluate(item, category, rawProfile);
    const rows = r.rows.map(d => `<tr><th scope="row">${escape(d.name)}</th><td>${d.percent.toFixed(1)}%</td><td>${d.value ?? 'Unknown'} / 4</td><td>${d.contribution.toFixed(2)}</td></tr><tr><td colspan="4">${escape(d.value === null ? 'No evidence supplied.' : d.anchors[Math.round(d.value)])} (${escape(d.source)}). ${includePrivate ? escape(d.reason) : ''}<br>${escape(d.why)}<details><summary>Full 0–4 scale</summary><ol start="0">${d.anchors.map(anchor => `<li>${escape(anchor)}</li>`).join('')}</ol></details></td></tr>`).join('');
    let source = '';
    if (includePrivate) {
      try { const url = new URL(item.url); if (['http:', 'https:'].includes(url.protocol)) source = `<p>Source: <a rel="noreferrer" href="${escape(url.href)}">${escape(url.href)}</a></p>`; } catch { /* No navigable source. */ }
    }
    return `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'"><title>8020 judgment card</title><style>body{font:16px/1.6 system-ui,sans-serif;color:#18181b;background:#fbfbfc;margin:0;padding:24px}main{max-width:720px;margin:auto}h1{line-height:1.2}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:10px;border-bottom:1px solid #e8e8ec}td[colspan]{font-size:14px;color:#45454c}strong{font-variant-numeric:tabular-nums}p{overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere}a{color:inherit}@media(max-width:450px){body{padding:12px}th,td{padding:6px}}</style><main><p>8020 Leverage / v${VERSION} / preferences revision ${r.revision}</p><h1>${includePrivate ? escape(item.title) : `Saved ${item.kind === 'memory' ? 'memory' : 'tab'} · private details omitted`}</h1><p><strong>${r.score === null ? 'Unassessed' : `${r.score}/100 · ${r.tier}`}</strong> — ${r.override ? 'user override' : r.complete ? 'weighted judgment' : 'missing evidence; not a zero score'}</p><table><caption>Dimension weights and contributions to the result</caption><thead><tr><th>Dimension</th><th>Weight</th><th>Rating</th><th>Points</th></tr></thead><tbody>${rows}</tbody></table><p>Formula: Σ(rating / 4 × normalized weight). Base ${r.base.toFixed(2)} + category adjustment ${r.adjustment.toFixed(2)} = ${r.computed.toFixed(1)} (clamped to 0–100). ${r.override ? `Final user override: ${r.override.score}. ${includePrivate ? escape(r.override.reason) : 'Reason omitted for privacy.'}` : ''}</p><p>Category learning: ${r.learnedCount} eligible correction(s); adjustment limited to ±20 points. Missing evidence is never inferred from an old category tier. S ≥85; A ≥70; B ≥50; C ≥30; D ≥10; F &lt;10. Existing category tiers are separate.</p><p>Evidence source: ${escape(r.provider)}. ${r.assessedAt ? `Assessed ${escape(r.assessedAt)}.` : 'Not assessed.'} AI ratings are inferences from supplied text, not verified page contents. Snapshot generated ${escape(new Date().toISOString())}; not a live or signed result.</p>${source}${includePrivate && item.kind === 'memory' ? `<pre>${escape(item.memory)}</pre>` : ''}<p>Open this file in any browser. No extension, script, tracking, or external assets required. ${includePrivate ? 'Private details included by the sharer.' : 'Titles, URLs, memory text, goals, and personal reasons omitted.'}</p></main></html>`;
  }
  const api = { VERSION, NAME, KEY, dimensions, defaults, profile, assessment, inputFor, fingerprint, evaluate, correct, manualAssessment, card, tier };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.PriorityJudgment = api;
})(globalThis);
