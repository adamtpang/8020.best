// Shared by the native classifier and extension worker. Avoid fuzzy matching:
// similar names such as Product and Projects can mean different things.
(function (root) {
  const aliases = {
    products: 'Product', 'product design': 'Product', 'product management': 'Product',
    project: 'Projects', 'tech news': 'Tech News', 'technology news': 'Tech News',
    'professional networking': 'Networking', 'personal finance': 'Wealth',
    'health and wellness': 'Health',
  };
  function categoryName(value) {
    const name = String(value || '').replace(/\s*\[[SABCDF]\]\s*$/i, '').trim().replace(/\s+/g, ' ');
    return aliases[name.toLowerCase()] || name;
  }
  function categoryKey(value) { return categoryName(value).toLowerCase(); }
  const tiers = ['S', 'A', 'B', 'C', 'D', 'F'];
  function consolidateCategories(folders) {
    const names = new Map(), groups = new Map(), result = [];
    for (const folder of folders) {
      // Archived collections retain their history outside the active library.
      if (folder.archived) { result.push({ ...folder, tabs: [...folder.tabs] }); continue; }
      const key = categoryKey(folder.name);
      if (!names.has(key)) names.set(key, categoryName(folder.name));
      const groupKey = key;
      if (!groups.has(groupKey)) {
        const group = { ...folder, name: names.get(key), tabs: [] };
        groups.set(groupKey, group); result.push(group);
      }
      const group = groups.get(groupKey);
      group.tabs.push(...folder.tabs);
      group.expanded = group.expanded || folder.expanded;
      // A category owns one tier. During migration, keep its most important
      // existing tier so a lower-priority duplicate cannot bury active work.
      if (tiers.includes(folder.tier) && (!tiers.includes(group.tier) || tiers.indexOf(folder.tier) < tiers.indexOf(group.tier))) group.tier = folder.tier;
      if (key === 'unsorted') group.tier = null;
    }
    return result;
  }
  const api = { categoryName, categoryKey, consolidateCategories };
  if (typeof module !== 'undefined') module.exports = api;
  else root.CategoryBuckets = api;
})(globalThis);
