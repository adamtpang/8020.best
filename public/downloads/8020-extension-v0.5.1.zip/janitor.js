(function(root) {
  const SETTINGS = '8020_janitor', STATUS = '8020_janitor_status', NEWEST = '8020_janitor_newest';
  const tiers = ['S','A','B','C','D','F'];
  const webTab = t => !t.incognito && /^https?:\/\//.test(t.url || '');
  function settings(value) {
    const limit = Number(value?.limit ?? 10);
    if (!Number.isInteger(limit) || limit < 2 || limit > 200) throw new Error('Choose a tab limit from 2 to 200.');
    return { enabled: value?.enabled === true, limit };
  }
  function candidates(tabs, newestId) {
    return tabs.filter(t => webTab(t) && !t.pinned && !t.active && !t.audible && t.status !== 'loading' && t.id !== newestId);
  }
  function newestId(tabs, newest) {
    return tabs.some(t=>t.id===newest?.id) ? newest.id : Math.max(-1,...tabs.map(t=>t.id));
  }
  function createJanitor({ chrome, classify, save, record }) {
    let running = false;
    const session = chrome.storage.session || chrome.storage.local;
    const status = value => chrome.storage.local.set({ [STATUS]: { ...value, updatedAt: new Date().toISOString() } });
    async function schedule() {
      const config = settings((await chrome.storage.local.get(SETTINGS))[SETTINGS]);
      if (config.enabled) await chrome.alarms?.create('8020-janitor', { delayInMinutes: 0.5 });
    }
    async function run() {
      if (running) return;
      running = true;
      try {
        const config = settings((await chrome.storage.local.get(SETTINGS))[SETTINGS]);
        if (!config.enabled) return;
        const previous = (await chrome.storage.local.get(STATUS))[STATUS];
        if (previous?.state === 'error' && Date.now() - Date.parse(previous.updatedAt) < 300000) return;
        const tabs = (await chrome.tabs.query({})).filter(webTab);
        if (tabs.length <= config.limit) { await status({ state:'idle', open:tabs.length, limit:config.limit }); return; }
        const newest = (await session.get(NEWEST))[NEWEST];
        // Browser tab IDs increase as tabs are created; conservative fallback
        // after enabling or a browser restart protects the highest current ID.
        const eligible = candidates(tabs, newestId(tabs, newest));
        if (!eligible.length) { await status({state:'protected',open:tabs.length,limit:config.limit, message:'Remaining tabs are protected.'}); return; }
        await status({state:'classifying',open:tabs.length,limit:config.limit});
        const decisions = await classify(eligible);
        if (decisions.length !== eligible.length || decisions.some(d=>!tiers.includes(d.tier)||!d.bucket)) throw new Error('Incomplete Jev decisions.');
        const ranked = eligible.map((tab,i)=>({ tab, ...decisions[i] })).sort((a,b)=>(Number.isFinite(a.score) && Number.isFinite(b.score) ? a.score-b.score : tiers.indexOf(b.tier)-tiers.indexOf(a.tier))||(a.tab.lastAccessed||0)-(b.tab.lastAccessed||0)||a.tab.id-b.tab.id);
        let closed = 0;
        for (const item of ranked) {
          const currentConfig = settings((await chrome.storage.local.get(SETTINGS))[SETTINGS]);
          if (!currentConfig.enabled) break;
          const currentTabs = (await chrome.tabs.query({})).filter(webTab);
          if (currentTabs.length <= currentConfig.limit) break;
          const currentNewest = (await session.get(NEWEST))[NEWEST];
          const protectedId = newestId(currentTabs, currentNewest);
          const tab = candidates(currentTabs, protectedId).find(t=>t.id===item.tab.id && t.url===item.tab.url && t.title===item.tab.title);
          if (!tab) continue;
          const saved = await record(tab);
          await save([{tab:saved,bucket:item.bucket,tier:item.tier,assessment:item.assessment}]);
          // Navigation, focus, audio and newest-tab state can change during save.
          const latest = (await chrome.tabs.query({})).filter(webTab);
          const latestNewest = (await session.get(NEWEST))[NEWEST];
          const configAfterSave = settings((await chrome.storage.local.get(SETTINGS))[SETTINGS]);
          const safe = candidates(latest, newestId(latest, latestNewest)).find(t=>t.id===tab.id && t.url===tab.url && t.title===tab.title);
          if (configAfterSave.enabled && latest.length > configAfterSave.limit && safe) {
            try { await chrome.tabs.remove(tab.id); closed++; } catch { /* Saved copy remains available. */ }
          }
        }
        const remaining = (await chrome.tabs.query({})).filter(webTab).length;
        await status({state:remaining>config.limit?'protected':'idle',open:remaining,limit:config.limit,closed,model:'~typesafe/jev-latest',message:remaining>config.limit?`Filed ${closed} tabs. Protected or changed tabs keep you above the limit.`:undefined});
      } catch(error) { await status({state:'error',message:error.message}); }
      finally { running=false; }
    }
    async function configure(value) {
      const config = settings(value);
      await chrome.storage.local.set({[SETTINGS]:config});
      await status({state:config.enabled?'idle':'paused',limit:config.limit});
      if (config.enabled) {
        const tabs = await chrome.tabs.query({});
        await session.set({[NEWEST]:{id:Math.max(-1,...tabs.map(t=>t.id))}});
        await schedule();
      } else await chrome.alarms?.clear('8020-janitor');
      return config;
    }
    function install() {
      chrome.tabs.onCreated?.addListener(tab=> { session.set({[NEWEST]:{id:tab.id}}).then(schedule).catch(()=>{}); });
      chrome.tabs.onUpdated?.addListener((_id,change)=> { if(change.status==='complete') schedule().catch(()=>{}); });
      chrome.tabs.onActivated?.addListener(()=>schedule().catch(()=>{}));
      chrome.alarms?.onAlarm.addListener(alarm=> { if(alarm.name==='8020-janitor') run(); });
      chrome.runtime.onStartup?.addListener(()=>schedule().catch(()=>{}));
      chrome.runtime.onInstalled?.addListener(()=>schedule().catch(()=>{}));
    }
    return {run,configure,install};
  }
  const api = {settings,candidates,createJanitor};
  if(typeof module !== 'undefined') module.exports=api; else root.TabJanitor=api;
})(globalThis);
