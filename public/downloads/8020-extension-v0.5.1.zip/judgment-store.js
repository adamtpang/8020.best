// Loaded after rubric.js. Uses the existing serialized folder writer for item mutations.
let judgmentWriteQueue = Promise.resolve();
async function getRubricProfile() {
  const data = await chrome.storage.local.get(PriorityJudgment.KEY);
  return PriorityJudgment.profile(data[PriorityJudgment.KEY]);
}
function writeRubric(change) {
  const operation = judgmentWriteQueue.then(async () => {
    const next = change(await getRubricProfile());
    await chrome.storage.local.set({ [PriorityJudgment.KEY]: next });
    return next;
  });
  judgmentWriteQueue = operation.catch(() => {});
  return operation;
}
async function handleJudgmentMessage(message) {
  const R = PriorityJudgment;
  if (message.type === 'RUBRIC_GET') return { profile: await getRubricProfile() };
  if (message.type === 'RUBRIC_UPDATE') {
    const updated = await writeRubric(current => {
      if (message.revision !== current.revision) throw new Error('Preferences changed in another window. Reopen the rubric and try again.');
      if (!R.dimensions.every(d => typeof message.weights?.[d.id] === 'number' && Number.isFinite(message.weights[d.id]) && message.weights[d.id] >= 0 && message.weights[d.id] <= 100) || !R.dimensions.some(d => message.weights[d.id] > 0)) throw new Error('Weights must be 0–100, with at least one greater than zero.');
      return R.profile({ ...current, weights: message.weights, goals: message.goals, revision: current.revision + 1, corrections: message.clearLearning ? current.corrections.map(c => ({ ...c, learn: false })) : current.corrections });
    });
    return { profile: updated };
  }
  if (message.type === 'RUBRIC_OVERRIDE') {
    const folders = await getFolders();
    const folder = folders.find(f => f.tabs.some(t => t.id === message.id));
    const item = folder?.tabs.find(t => t.id === message.id);
    if (!item) throw new Error('This item no longer exists.');
    return { profile: await writeRubric(p => R.correct(p, item, folder.name, message.score, message.reason, message.learn)) };
  }
  if (message.type === 'RUBRIC_EVIDENCE') {
    let found = false;
    await setFolders(current => current.map(f => ({ ...f, tabs: f.tabs.map(item => {
      if (item.id !== message.id) return item;
      found = true;
      if (message.inputHash !== R.fingerprint(R.inputFor(item))) throw new Error('This item changed. Reopen it before saving evidence.');
      return { ...item, assessment: R.manualAssessment(item, message.values || {}, message.reasons || {}) };
    }) })));
    if (!found) throw new Error('This item no longer exists.');
    return { ok: true };
  }
  if (message.type === 'MEMORY_SAVE') {
    const title = typeof message.title === 'string' ? message.title.trim().slice(0, 300) : '';
    const memory = typeof message.memory === 'string' ? message.memory.trim().slice(0, 10000) : '';
    const name = categoryName(message.category || 'Memories').slice(0, 100);
    if (!title || !memory) throw new Error('Give the memory a title and text.');
    const item = { id: generateId(), kind: 'memory', title, memory, url: '', createdAt: new Date().toISOString() };
    await setFolders(current => {
      const target = current.find(f => !f.archived && categoryKey(f.name) === categoryKey(name));
      return target ? current.map(f => f.id === target.id ? { ...f, tabs: [...f.tabs, item] } : f) : [...current, { id: generateId(), name, tier: null, tabs: [item], expanded: true }];
    });
    return { id: item.id };
  }
  if (message.type === 'RUBRIC_ASSESS') {
    if (!(await hasNativeMessagingPermission())) throw new Error('Grant optional local companion access first.');
    if (!Array.isArray(message.ids) || message.ids.length < 1 || message.ids.length > 30) throw new Error('Assess 1–30 items at a time.');
    const ids = new Set(message.ids);
    const folders = await getFolders();
    const items = folders.flatMap(f => f.tabs).filter(t => ids.has(t.id));
    if (!items.length) throw new Error('No matching saved items.');
    const rubric = await getRubricProfile();
    const result = await sendNativeMessage({ type: 'sort', batch: items.map(R.inputFor), existingBuckets: bucketNamesFor(folders), rubric });
    if (result?.error) throw new Error(result.error);
    const remaining = [...(result?.tasks || [])], assessments = new Map();
    for (const item of items) {
      const index = remaining.findIndex(t => t.text === R.inputFor(item));
      if (index < 0 || !remaining[index].assessment) throw new Error('The companion returned no rubric evidence. Update the local companion and try again.');
      const evidence = remaining.splice(index, 1)[0].assessment;
      if (evidence.version !== R.VERSION || evidence.inputHash !== R.fingerprint(R.inputFor(item)) || typeof evidence.provider !== 'string' || !R.dimensions.every(d => {
        const entry = evidence.dimensions?.[d.id];
        return entry && (entry.value === null || (Number.isInteger(entry.value) && entry.value >= 0 && entry.value <= 4)) && typeof entry.reason === 'string';
      })) throw new Error('The companion returned invalid rubric evidence. Existing judgments were not changed.');
      assessments.set(item.id, R.assessment(evidence, R.inputFor(item)));
    }
    let saved = 0;
    await setFolders(current => current.map(f => ({ ...f, tabs: f.tabs.map(item => {
      const next = assessments.get(item.id);
      if (!next || next.inputHash !== R.fingerprint(R.inputFor(item))) return item;
      saved++;
      return { ...item, assessment: next };
    }) })));
    return { saved, skipped: items.length - saved };
  }
  throw new Error('Unknown rubric action.');
}
