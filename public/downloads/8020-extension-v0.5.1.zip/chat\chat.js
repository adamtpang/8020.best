// 8020 chat side panel. The conversation lives in chrome.storage.session so
// it survives closing and reopening the panel, but not a browser restart.
const KEY = "8020_chat";
const log = document.getElementById("log");
const empty = document.getElementById("empty");
const form = document.getElementById("form");
const input = document.getElementById("input");
const send = document.getElementById("send");
const contextLabel = document.getElementById("context");
let messages = [];
let busy = false;

function escapeHtml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// Small, safe markdown: escape first, then bold, code, and bullet/number lists.
function renderMarkdown(text) {
  const inline = (s) => escapeHtml(s)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  const out = [];
  let list = null;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trimEnd();
    const bullet = line.match(/^\s*[-*]\s+(.*)/);
    const numbered = line.match(/^\s*\d+[.)]\s+(.*)/);
    const kind = bullet ? "ul" : numbered ? "ol" : null;
    if (kind) {
      if (list !== kind) { if (list) out.push(`</${list}>`); out.push(`<${kind}>`); list = kind; }
      out.push(`<li>${inline((bullet || numbered)[1])}</li>`);
      continue;
    }
    if (list) { out.push(`</${list}>`); list = null; }
    if (!line.trim()) continue;
    const heading = line.match(/^#{1,4}\s+(.*)/);
    out.push(heading ? `<p><strong>${inline(heading[1])}</strong></p>` : `<p>${inline(line)}</p>`);
  }
  if (list) out.push(`</${list}>`);
  return out.join("");
}

function bubble(role, text, extra = "") {
  const el = document.createElement("div");
  el.className = `msg ${role} ${extra}`.trim();
  if (role === "assistant" && !extra) el.innerHTML = renderMarkdown(text);
  else el.textContent = text;
  log.appendChild(el);
  log.scrollTop = log.scrollHeight;
  return el;
}

function render() {
  log.querySelectorAll(".msg").forEach((el) => el.remove());
  empty.hidden = messages.length > 0;
  for (const m of messages) bubble(m.role, m.content);
}

async function save() {
  await chrome.storage.session.set({ [KEY]: messages });
}

async function refreshContext() {
  const { count } = await chrome.runtime.sendMessage({ type: "CHAT_CONTEXT_COUNT" });
  contextLabel.textContent = `sees ${count} open tab${count === 1 ? "" : "s"}`;
}

async function ask(text) {
  if (busy || !text.trim()) return;
  // Chat goes through the local companion, which needs this optional
  // permission. Requesting it here keeps it tied to the user's click.
  if (!(await chrome.permissions.request({ permissions: ["nativeMessaging"] }))) {
    bubble("assistant", "Chat needs the 8020 companion permission. Click Send again and allow it.", "error");
    return;
  }
  busy = true;
  send.disabled = true;
  messages.push({ role: "user", content: text.trim() });
  empty.hidden = true;
  bubble("user", text.trim());
  input.value = "";
  const pending = bubble("assistant", "Looking at your tabs...", "pending");
  try {
    const res = await chrome.runtime.sendMessage({ type: "CHAT", messages });
    pending.remove();
    if (res?.error) {
      messages.pop();
      bubble("assistant", res.error, "error");
    } else {
      messages.push({ role: "assistant", content: res.reply });
      bubble("assistant", res.reply);
      contextLabel.textContent = `sees ${res.openTabCount} open tab${res.openTabCount === 1 ? "" : "s"}`;
    }
    await save();
  } catch (err) {
    pending.remove();
    messages.pop();
    bubble("assistant", err instanceof Error ? err.message : String(err), "error");
  } finally {
    busy = false;
    send.disabled = false;
    input.focus();
  }
}

form.addEventListener("submit", (e) => { e.preventDefault(); ask(input.value); });
input.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); ask(input.value); }
});
document.querySelectorAll(".chips button").forEach((b) => b.addEventListener("click", () => ask(b.dataset.q)));
document.getElementById("clear").addEventListener("click", async () => {
  messages = [];
  await save();
  render();
});
chrome.tabs.onCreated.addListener(refreshContext);
chrome.tabs.onRemoved.addListener(refreshContext);

chrome.storage.session.get(KEY).then((data) => {
  messages = data[KEY] || [];
  render();
});
refreshContext();
input.focus();
