# 8020 companion

Optional. The 8020 extension saves, searches, prioritizes, and restores tabs without it. The companion adds AI sorting, assessment, and chat by running a small local program that Chrome starts only when you use an AI feature.

## Install (about two minutes)

1. Install [Node.js](https://nodejs.org) 20 or newer.
2. Unzip this folder somewhere you will keep it (Chrome runs the companion from here).
3. In a terminal inside `server/`, run:

   ```
   node install.js
   ```

   This registers the companion for your user only, in Chrome, Helium, Chromium, Edge, and Brave. No admin rights needed. It trusts the 8020 builds from the Chrome Web Store and from https://8020.best/download. If you loaded 8020 some other way, add your ID from your extensions page: `node install.js --extension-id <id>`.
4. Choose an AI provider:
   - **Jev sorting:** create `.env.local` next to the `server/` folder containing `OPENROUTER_API_KEY=your-key` (copy `.env.local.example`).
   - **Chat and focus analysis:** install [Claude Code](https://claude.com/claude-code) and run `claude` once to sign in. It uses your Claude plan.
5. Reload 8020 on your extensions page and start an AI action. 8020 shows exactly what is sent before anything leaves your computer.

## Remove

```
node install.js --uninstall
```

## Privacy

The companion sends only what the in-extension disclosure lists, only to the provider you set up, and only when you start an AI action. See https://8020.best/privacy.
