#!/usr/bin/env node
// Registers the 8020 companion as a Chrome native messaging host for the
// current user, in every Chromium browser that is installed.
//
//   node install.js                         # trust the store and download builds
//   node install.js --extension-id <id>     # also trust a dev build's ID
//   node install.js --uninstall
//
// Writes only per-user locations (HKCU on Windows, the browser's
// NativeMessagingHosts folder on macOS and Linux). Needs no admin rights.
"use strict";
const fs = require("fs");
const os = require("os");
const path = require("path");
const { execFileSync } = require("child_process");

const HOST = "com.eightytwenty.sortserver";
// Chrome Web Store item, and the fixed ID of the https://8020.best/download
// build (derived from scripts/download-build.pubkey).
const KNOWN_IDS = ["hjnoblncmfgibmkbappbndbledimmkme", "pmbemhkbddpopmlkmffpnfajaoggeafl"];

const BROWSERS = {
  win32: [
    // Helium on Windows reads Chrome's key (verified 2026-11-03).
    ["Google Chrome and Helium", "Software\\Google\\Chrome"],
    ["Chromium", "Software\\Chromium"],
    ["Microsoft Edge", "Software\\Microsoft\\Edge"],
    ["Brave", "Software\\BraveSoftware\\Brave-Browser"],
  ],
  darwin: [
    ["Google Chrome", "Library/Application Support/Google/Chrome"],
    ["Chromium", "Library/Application Support/Chromium"],
    ["Microsoft Edge", "Library/Application Support/Microsoft Edge"],
    ["Brave", "Library/Application Support/BraveSoftware/Brave-Browser"],
  ],
  linux: [
    ["Google Chrome", ".config/google-chrome"],
    ["Chromium", ".config/chromium"],
    ["Microsoft Edge", ".config/microsoft-edge"],
    ["Brave", ".config/BraveSoftware/Brave-Browser"],
  ],
};

function parseArgs(argv) {
  const args = { ids: [], uninstall: false };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === "--uninstall") args.uninstall = true;
    else if (argv[i] === "--extension-id") args.ids.push(argv[++i]);
    else if (argv[i] === "--help" || argv[i] === "-h") args.help = true;
    else throw new Error(`Unknown option ${argv[i]}`);
  }
  for (const id of args.ids) if (!/^[a-p]{32}$/.test(id || "")) throw new Error(`"${id}" is not an extension ID (32 letters a to p, shown on chrome://extensions).`);
  return args;
}

function hostManifest(dir, ids, platform) {
  return {
    name: HOST,
    description: "8020 companion: optional local AI bridge for the 8020 tab manager",
    path: path.join(dir, platform === "win32" ? "host.bat" : "host.sh"),
    type: "stdio",
    allowed_origins: [...new Set([...KNOWN_IDS, ...ids])].map((id) => `chrome-extension://${id}/`),
  };
}

function install({ ids, dir = __dirname, platform = process.platform, home = os.homedir(), reg = regWrite, log = console.log } = {}) {
  const browsers = BROWSERS[platform];
  if (!browsers) throw new Error(`Unsupported platform ${platform}`);
  const manifest = hostManifest(dir, ids, platform);
  const manifestPath = path.join(dir, `${HOST}.json`);
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + "\n");
  if (platform !== "win32") fs.chmodSync(manifest.path, 0o755);
  const done = [];
  for (const [name, base] of browsers) {
    if (platform === "win32") {
      reg(`HKCU\\${base}\\NativeMessagingHosts\\${HOST}`, manifestPath);
      done.push(name);
    } else {
      const profile = path.join(home, base);
      if (!fs.existsSync(profile)) continue; // browser not installed
      const target = path.join(profile, "NativeMessagingHosts");
      fs.mkdirSync(target, { recursive: true });
      fs.writeFileSync(path.join(target, `${HOST}.json`), JSON.stringify(manifest, null, 2) + "\n");
      done.push(name);
    }
  }
  log(`Registered the 8020 companion for: ${done.join(", ") || "no browsers found"}.`);
  log(`Trusted extension IDs: ${manifest.allowed_origins.map((o) => o.slice(19, -1)).join(", ")}`);
  return { manifest, browsers: done };
}

function uninstall({ dir = __dirname, platform = process.platform, home = os.homedir(), regDelete = regRemove, log = console.log } = {}) {
  for (const [, base] of BROWSERS[platform] || []) {
    if (platform === "win32") regDelete(`HKCU\\${base}\\NativeMessagingHosts\\${HOST}`);
    else fs.rmSync(path.join(home, base, "NativeMessagingHosts", `${HOST}.json`), { force: true });
  }
  fs.rmSync(path.join(dir, `${HOST}.json`), { force: true });
  log("Unregistered the 8020 companion. The extension keeps working without AI.");
}

function regWrite(key, value) {
  execFileSync("reg", ["add", key, "/ve", "/t", "REG_SZ", "/d", value, "/f"], { stdio: "ignore" });
}
function regRemove(key) {
  try { execFileSync("reg", ["delete", key, "/f"], { stdio: "ignore" }); } catch { /* not present */ }
}

function nextSteps(log = console.log) {
  const env = path.join(__dirname, "..", ".env.local");
  log("");
  log("Next:");
  log(" 1. Reload 8020 on your extensions page.");
  log(` 2. For Jev sorting, put OPENROUTER_API_KEY=... in ${env}`);
  log("    For chat and focus analysis, install Claude Code and run `claude` once to sign in.");
  log(" 3. In 8020, start an AI action. You will see what is sent before anything leaves your computer.");
}

if (require.main === module) {
  try {
    const args = parseArgs(process.argv.slice(2));
    if (args.help) console.log(fs.readFileSync(__filename, "utf8").split("\n").slice(1, 10).join("\n").replace(/^\/\/ ?/gm, ""));
    else if (args.uninstall) uninstall();
    else { install({ ids: args.ids }); nextSteps(); }
  } catch (err) {
    console.error(`8020 companion install failed: ${err.message}`);
    process.exit(1);
  }
}

module.exports = { install, uninstall, hostManifest, parseArgs, KNOWN_IDS, HOST };
