// Chrome Native Messaging host for the 8020 extension. Chrome launches this
// process itself, on demand, each time the extension calls
// chrome.runtime.sendNativeMessage -- no server to start, nothing running
// when you're not using the extension. See README.md for the one-time
// registration step that tells Chrome this host exists.
//
// Wire protocol (fixed by the native messaging spec): each message, both
// directions, is a 4-byte little-endian length prefix followed by that many
// bytes of UTF-8 JSON.
const { sortBatch, analyzeFocusTabs, runClaude, describeSources, describeModel } = require("./lib/classify");
const { writeMarkdownMirror } = require("./lib/markdown-mirror");
const { chatAboutTabs } = require("./lib/chat");
const {
  analyzeProjectRoutes,
  loadProjectCatalog,
} = require("./lib/project-routing");

function sendMessage(obj) {
  const json = Buffer.from(JSON.stringify(obj), "utf8");
  const header = Buffer.alloc(4);
  header.writeUInt32LE(json.length, 0);
  process.stdout.write(header);
  process.stdout.write(json);
}

async function handleMessage(msg) {
  if (msg?.type === "health") {
    sendMessage({ ok: true });
    return;
  }
  if (msg?.type === "sort") {
    try {
      const tasks = await sortBatch(msg.batch, msg.existingBuckets, msg.rubric);
      // sources/model ride along so the UI can state what the triage was
      // actually weighted against instead of just showing a spinner.
      sendMessage({ tasks, sources: describeSources(), model: describeModel() });
    } catch (err) {
      sendMessage({ error: err instanceof Error ? err.message : String(err) });
    }
    return;
  }
  if (msg?.type === "analyze_focus") {
    try {
      const recommendations = await analyzeFocusTabs(msg.tabs, msg.limit);
      const projects = loadProjectCatalog();
      const routes = await analyzeProjectRoutes(msg.routingTabs, projects, runClaude);
      sendMessage({
        recommendations,
        projects,
        routes,
        sources: describeSources(),
        model: describeModel(),
      });
    } catch (err) {
      sendMessage({ error: err instanceof Error ? err.message : String(err) });
    }
    return;
  }
  if (msg?.type === "chat") {
    try {
      const reply = await chatAboutTabs(msg);
      sendMessage({ reply, model: describeModel() });
    } catch (err) {
      sendMessage({ error: err instanceof Error ? err.message : String(err) });
    }
    return;
  }
  if (msg?.type === "mirror_markdown") {
    try {
      const result = writeMarkdownMirror(msg.markdown);
      sendMessage({ ok: true, ...result });
    } catch (err) {
      sendMessage({ error: err instanceof Error ? err.message : String(err) });
    }
    return;
  }
  sendMessage({ error: `unknown message type: ${msg?.type}` });
}

let buffer = Buffer.alloc(0);
let messageQueue = Promise.resolve();
process.stdin.on("data", (chunk) => {
  buffer = Buffer.concat([buffer, chunk]);
  while (buffer.length >= 4) {
    const length = buffer.readUInt32LE(0);
    if (buffer.length < 4 + length) break;
    const messageBuf = buffer.subarray(4, 4 + length);
    buffer = buffer.subarray(4 + length);
    messageQueue = messageQueue.then(async () => {
      try {
        await handleMessage(JSON.parse(messageBuf.toString("utf8")));
      } catch (err) {
        sendMessage({ error: `bad message: ${err instanceof Error ? err.message : String(err)}` });
      }
    });
  }
});

// Chrome closes stdin when it's done with this host (end of the single
// request/response for sendNativeMessage) -- exit cleanly rather than hang.
process.stdin.on("end", () => {
  messageQueue.finally(() => {
    process.exitCode = 0;
  });
});
