#!/bin/sh
# macOS and Linux launcher for the 8020 native messaging host. Chrome starts
# this with a minimal environment, so look for node in the usual places too.
DIR="$(cd "$(dirname "$0")" && pwd)"
PATH="$PATH:/opt/homebrew/bin:/usr/local/bin:$HOME/.volta/bin:$HOME/.local/bin"
for n in "$HOME"/.nvm/versions/node/*/bin; do [ -d "$n" ] && PATH="$PATH:$n"; done
export PATH
exec node "$DIR/native-host.js" "$@"
