@echo off
REM Native messaging hosts must be a directly-executable file (no argv Chrome
REM can pass flags through) -- this batch file is the standard Windows
REM workaround for a Node-based host. %~dp0 is this file's own directory, so
REM it works regardless of where the repo is cloned.
node "%~dp0native-host.js" %*
